"""Version information for Wikipedia-API."""

__version__ = (0, 16, 0)
__version_str__ = ".".join(str(s) for s in __version__)
